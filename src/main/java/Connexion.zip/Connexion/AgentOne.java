package Connexion;

import jade.core.Agent;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;


// 1.10 dk

enum Colors {
    Red(0), Blue(1), Green(2);

    public final int val;

    Colors(int val){
        this.val = val;
    }
}

public class AgentOne extends Agent {
    FSMBehaviour fsm = new FSMBehaviour();
    Colors currentColor = null;
    int chance = 1;
    boolean IsPressed = false;

    public static int product_points =0;
    public static int press_counts =0;

    OneShotBehaviour Read = new OneShotBehaviour() {



        String[] sequence = new String[]{"Red","Red","Green","Green","Blue","Green","Red","Blue","Red","Blue","Blue","Blue"};

        String[] sequence1 = new String[]{"Blue","Green","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Green","Red","Blue","Blue","Red","Green","Green","Green","Blue","Red","Red","Green","Red","Green","Green","Red","Green","Red","Red","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Green","Red","Green","Green","Blue","Green","Green","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Red","Green","Blue","Green","Blue","Green","Blue","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Green",

                "Green","Red","Green","Blue","Green","Red","Green","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Blue","Green","Green","Blue","Red","Blue","Red","Green","Red","Red","Red","Green","Red","Red","Red","Blue","Red","Green","Red","Red","Red","Red","Green","Green","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Green","Red","Green","Green","Red","Red","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Red","Green","Red","Blue","Red","Blue","Green","Red","Red","Green","Green","Green","Red",

                "Green","Blue","Red","Green","Red","Blue","Blue","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Blue","Green","Red","Blue","Green","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Red","Red","Blue","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Red","Green","Green","Green","Green","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Blue","Green","Red","Green","Red","Green","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Blue","Green","Green","Green","Blue","Green","Red","Green","Red","Green","Green",

                "Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Red","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Blue","Red","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Green","Red","Green","Red","Red","Green","Green","Blue","Blue","Red","Red","Blue","Red","Green","Green","Green","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Green","Blue","Blue","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Blue","Green","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Blue","Red","Red","Blue","Green",

                "Red","Red","Red","Blue","Red","Green","Green","Blue","Blue","Green","Green","Green","Green","Red","Red","Green","Blue","Green","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Red","Blue","Red","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Green","Green","Green","Green","Green","Blue","Green","Red","Blue","Red","Blue","Blue","Green","Red","Green","Green","Red","Blue","Green","Red","Red","Green","Green","Blue","Red","Green","Blue","Blue","Green","Green","Blue","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Green","Green","Red","Green","Green","Blue","Red","Green","Green","Blue","Red","Green","Red","Red","Green","Red","Red","Red","Green","Green",

                "Red","Red","Green","Red","Blue","Green","Red","Green","Green","Green","Blue","Blue","Green","Red","Blue","Green","Green","Red","Blue","Red","Green","Red","Red","Red","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Red","Green","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Red","Green","Green","Blue","Green","Green","Green","Blue","Green","Green","Blue","Green","Green","Blue","Red","Red","Red","Green","Red","Red","Red","Green","Red","Green","Red","Green","Red","Red","Green","Red","Red","Green","Blue","Red",

                "Blue","Red","Red","Red","Red","Red","Blue","Red","Red","Red","Green","Red","Blue","Red","Blue","Blue","Red","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Blue","Red","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Green","Red","Blue","Blue","Blue","Green","Blue","Red","Red","Red","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Red","Green","Blue","Red","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Green","Blue","Blue","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Blue",

                "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Blue","Red","Blue","Blue","Red","Red","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Green","Red","Green","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Red","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Blue","Blue","Blue","Red","Red","Green","Blue","Red","Red","Green","Blue","Red","Green","Green","Blue",

                "Blue","Red","Green","Green","Blue","Blue","Red","Red","Red","Green","Red","Blue","Green","Green","Green","Blue","Green","Blue","Green","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Red","Green","Blue","Blue","Red","Red","Blue","Red","Red","Green","Blue","Green","Blue","Blue","Red","Blue","Red","Red","Green","Green","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Red","Blue","Green","Blue","Green","Red","Red","Blue","Green","Red","Blue","Green",

                "Red","Red","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Green","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Blue","Green","Red","Green","Green","Red","Red","Green","Red","Blue","Green","Red","Green","Red","Red","Blue","Blue","Green","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Green","Red","Green","Red","Green","Red","Red","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Green","Green","Green","Red","Green","Green","Red","Blue","Green","Green","Green","Green","Green","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Blue","Blue",

                "Red","Red","Green","Blue","Red","Red","Green","Green","Red","Blue","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Blue","Green","Green","Green","Blue","Green","Green","Blue","Blue","Green","Red","Red","Red","Blue","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Green","Green","Red","Blue","Green","Green","Red","Red","Blue","Green","Red","Blue","Red","Red","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Blue","Green","Blue",

                "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Red","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Blue","Red","Green","Blue","Red","Blue","Red","Blue","Blue","Green","Red","Red","Red","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Red","Red","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Green","Blue","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Red","Red","Green","Green","Red","Red","Blue","Red","Red","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Green",

                "Blue","Red","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Green","Green","Green","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Green","Green","Red","Red","Red","Green","Green","Red","Blue","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Red","Red","Blue","Green","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Green","Red",

                "Blue","Red","Red","Green","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Blue","Blue","Green","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Red","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Green","Green","Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Red","Green","Green","Blue","Green","Green","Blue","Green","Blue","Blue","Red","Blue","Green","Red","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Blue","Blue","Green","Red","Red","Green","Blue",

                "Red","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Red","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Red","Green","Blue","Blue","Red","Green","Red","Blue","Green","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Red","Red","Green","Green",

                "Green","Red","Blue","Blue","Red","Blue","Blue","Red","Blue","Blue","Blue","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Blue","Red","Green","Red","Red","Blue","Red","Blue","Green","Green","Red","Red","Red","Red","Blue","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Green","Blue","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Green","Green","Blue","Blue","Red","Green","Red","Green","Green","Red","Red","Blue","Red","Red",

                "Green","Green","Red","Green","Green","Red","Green","Blue","Blue","Green","Green","Blue","Red","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Blue","Green","Blue","Green","Blue","Red","Green","Green","Green","Blue","Green","Red","Blue","Green","Blue","Green","Green","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue",

                "Blue","Green","Blue","Red","Blue","Blue","Red","Green","Red","Red","Red","Green","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Green","Blue","Blue","Red","Red","Red","Red","Red","Green","Red","Green","Red","Red","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Green","Green","Red","Red","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Red","Green","Red","Blue","Red","Green","Blue","Green","Blue","Red","Red","Blue","Blue","Green","Red","Red","Red","Red","Green","Red","Blue","Green","Blue","Blue","Red","Blue",

                "Green","Red","Red","Green","Red","Red","Blue","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Blue","Red","Red","Blue","Red","Blue","Red","Red","Green","Blue","Blue","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Red","Red","Blue","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Blue","Red",

                "Red","Green","Red","Green","Blue","Green","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Green","Green","Blue","Green","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Red","Green","Red","Green","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Blue","Blue","Green","Red","Red","Green","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Green","Green","Green","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Green","Green","Red","Red","Blue","Red","Blue","Blue","Red","Green","Green","Blue",

                "Green","Red","Blue","Red","Green","Green","Red","Blue","Green","Green","Green","Red","Red","Blue","Red","Green","Blue","Red","Green","Green","Blue","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Red","Red","Blue","Green","Red","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Blue","Red","Green","Green","Green","Red","Red","Red","Red","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Red","Green","Red","Green","Red","Blue","Green","Green",

                "Blue","Red","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Blue","Green","Green","Green","Green","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Blue","Red","Red","Red","Red","Blue","Green","Red","Red","Blue","Green","Green","Green","Red","Red","Blue","Green","Green","Red","Blue","Red","Red","Green","Blue","Red","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Red","Green","Green","Green","Green","Green","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue",

                "Red","Green","Green","Red","Red","Red","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Green","Red","Blue","Green","Green","Blue","Green","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Green","Red","Blue","Red","Blue","Green","Green","Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Blue","Red","Green","Green","Green","Blue","Green","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Green","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Blue","Red",

                "Blue","Green","Green","Red","Red","Blue","Green","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Red","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Blue","Red","Blue","Green","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Red","Green","Red","Blue","Red","Green","Green","Red","Red","Green","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Green","Green","Green","Blue","Blue","Green","Green","Red","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Blue","Blue","Blue","Red",

                "Red","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Blue","Green","Blue","Red","Red","Green","Blue","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Green","Blue","Blue","Red","Red","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Red","Red","Green","Green","Green","Blue","Blue","Blue","Green","Red","Blue","Red","Red","Red","Red","Green","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Blue","Red","Green","Red","Blue","Blue","Red","Red","Green","Red","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Red","Blue","Red",

                "Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Red","Green","Green","Red","Red","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Green","Green","Blue","Red","Green","Red","Red","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Red","Red","Red","Red","Red","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Green","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Green",

                "Red","Red","Green","Blue","Green","Blue","Red","Green","Blue","Green","Green","Green","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Red","Red","Green","Green","Blue","Blue","Blue","Blue","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Green","Green","Blue","Blue",

                "Red","Red","Red","Blue","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Blue","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Green","Green","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Blue","Red","Blue","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Red","Green","Blue","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Red","Red","Red","Green","Blue","Green","Blue","Green","Red","Red","Green","Red","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Red","Red","Green","Blue","Green","Red","Green",

                "Green","Green","Blue","Red","Red","Green","Blue","Red","Green","Blue","Red","Blue","Green","Blue","Green","Green","Green","Blue","Green","Blue","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Red","Red","Green","Green","Red","Green","Blue","Green","Red","Green","Red","Green","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Green","Red","Green","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Green","Blue","Green","Blue","Green","Blue","Red","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Red","Blue","Blue","Blue","Green","Blue","Green","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Red","Red","Green","Red","Red","Red","Blue",

                "Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Blue","Blue","Blue","Green","Blue","Red","Red","Green","Green","Blue","Blue","Red","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Red","Green","Blue","Blue","Green","Red","Red","Blue","Red","Red","Blue","Blue","Red","Green","Green","Red","Blue","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Green","Blue","Blue","Red","Red","Green","Green","Red","Green","Blue","Blue","Green",

                "Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Red","Red","Red","Red","Green","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Red","Red","Red","Green","Red","Blue","Blue","Green","Green","Green","Green","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Green","Red","Green","Green","Blue","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Green","Green","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Green","Red","Red","Blue","Red","Red","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue"};
        int currentIndex = 0;
        Colors color = null;
        @Override
        public void action() {
            while (currentIndex < sequence.length) {
                switch(sequence[currentIndex++]){
                    case "Red":
                        color=Colors.Red;
                        return;
                    case "Blue":
                        color=Colors.Blue;
                        return;
                    case "Green":
                        color=Colors.Green;
                        return;
                }
            }
            if(currentIndex >= sequence.length){
                block();
            }
        }

        @Override
        public int onEnd() {
            System.out.println("Color READ:" + color );
            return color.val;
        }
    };

    OneShotBehaviour Red = new OneShotBehaviour() {
        @Override
        public void action() {

            if (currentColor != null && currentColor != Colors.Red) {
                // Eger gelen renk kirmizi ise ama elimizde kirmizi disinda birsey var hemen ejectliyoruz
                Eject();
                currentColor = null;
            }

            if (currentColor == null) {
                // Haznede hicbir renk yoksa ve gelen red ise hemen press1 ile basiyoruz
                currentColor = Colors.Red;
                Press1();
            } else {
                // eger elimize kirmizi geldiysa ve elimizde kirmizi varsa build edip ejectliyoruz
                BuildAndEject();
                currentColor = null;
            }
        }
    };

    OneShotBehaviour Blue = new OneShotBehaviour() {
        @Override
        public void action() {
            if (currentColor == null) {
                // eger elimizde hicbirsey yoksa maviyi aliyoruz ama basmiyoruz
                currentColor = Colors.Blue;
            } else if (currentColor == Colors.Red) {
                // eger elimizde kirmizi var ve mavi geldiyse
                if (chance != 0) { // atma sansimiz var ise atiyoruz
                    chance--;
                    Eject();
                } else {
                    // atma sansimiz yoksa birlestirip urun buildliyoruz
                    BuildAndEject();
                }
            } else if (currentColor == Colors.Blue) {
                // Elimizde mavi varsa ve mavi geldiysa urun buildliyoruz
                BuildAndEject();
            } else {
                // Elimize yesil varsa ve mavi gelirse ejectliyoruz basmiyoruz hicbirsekilde artik yeni rengimiz Mavi
                Eject();
                currentColor = Colors.Blue;
            }
        }
    };

    OneShotBehaviour Green = new OneShotBehaviour() {
        @Override
        public void action() {
            if (currentColor == null) {
                // eger elimizde hicbirsey yoksa yesili aliyoruz ama basmiyoruz
                currentColor = Colors.Green;
            } else if (currentColor == Colors.Red) {
                // eger elimizde kirmizi var ve yesil geldiyse
                if (chance != 0) { // atma sansimiz var ise atiyoruz
                    chance--;
                    Eject();
                } else {
                    // atma sansimiz yoksa birlestirip urun buildliyoruz
                    BuildAndEject();
                }
            } else if (currentColor == Colors.Green) {
                // Elimizde mavi varsa ve yesil geldiysa urun buildliyoruz
                BuildAndEject();
            } else {
                // Elimizde mavi varsa ve yesil gelirse ejectliyoruz basmiyoruz hicbirsekilde artik yeni rengimiz yesil
                Eject();
                currentColor = Colors.Green;
            }
        }
    };


    @Override
    protected void setup() {
        System.out.println("local name" + getAID().getLocalName());
        System.out.println("GloBal name" + getAID().getName());

        fsm.registerDefaultTransition("Red","Read");
        fsm.registerDefaultTransition("Blue","Read");
        fsm.registerDefaultTransition("Green","Read");

        fsm.registerTransition("Read","Red",Color.Red.val);
        fsm.registerTransition("Read","Blue",Color.Blue.val);
        fsm.registerTransition("Read","Green",Color.Green.val);

        fsm.registerFirstState(Read, "Read");
        fsm.registerLastState(Read, "ReadLast");
        fsm.registerState(Blue, "Blue");
        fsm.registerState(Green, "Green");
        fsm.registerState(Red, "Red");
        addBehaviour(fsm);

    }


    @Override
    protected void takeDown() {

    }

    public void Eject() {
        System.out.println("Eject");
    }

    public void Press1() {
        IsPressed = true;
        System.out.println("Press1");
    }

    public void Press2() {
        System.out.println("Press2");
    }

    public void BuildAndEject() {
        currentColor = null;
        chance = 0;
        if (!IsPressed) {
            Press1();
        }
        IsPressed=false;
        Press2();
        Eject();
    }


}
