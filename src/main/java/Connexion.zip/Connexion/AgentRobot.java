package Connexion;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

import ev3dev.actuators.lego.motors.EV3MediumRegulatedMotor;
import ev3dev.sensors.ev3.EV3UltrasonicSensor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

import static jade.lang.acl.ACLMessage.INFORM;

public class AgentRobot extends Agent {

    static EV3MediumRegulatedMotor leftMotor = new EV3MediumRegulatedMotor(MotorPort.A);
    static EV3MediumRegulatedMotor rightMotor = new EV3MediumRegulatedMotor(MotorPort.B);
    static EV3UltrasonicSensor ultrasonicSensor = new EV3UltrasonicSensor(SensorPort.S1);

    public static double get_ultrasonic_dist(EV3UltrasonicSensor us) {
        SampleProvider provider = us.getDistanceMode();
        float[] samples = new float[provider.sampleSize()];
        provider.fetchSample(samples, 0);
        return samples[0];
    }

    @Override
    protected void setup() {
        System.out.println("Local name Robot3: " + getAID().getLocalName());
        System.out.println("Global name Robot3: " + getAID().getName());

        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                try {
                    ACLMessage message = receive();
                    if (message != null) {
                        System.out.println("Agent Robot Received: " + message.getContent());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        addBehaviour(init_message);
        addBehaviour(robotControlBehaviour);
    }

    @Override
    protected void takeDown() {
        leftMotor.stop();
        rightMotor.stop();
        System.out.println("Agent shutting down.");
    }

    OneShotBehaviour init_message = new OneShotBehaviour() {
        @Override
        public void action() {
            try {
                ACLMessage messageTemplate = new ACLMessage(INFORM);
                messageTemplate.addReceiver(new AID("AgentMain@192.168.0.117:1099/JADE", AID.ISGUID));
                messageTemplate.setContent("This is one-shot - I am alive.");
                send(messageTemplate);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    TickerBehaviour robotControlBehaviour = new TickerBehaviour(this, 100) {
        int targetDistance = 20;
        int rotationTimeMs = 3600;

        @Override
        protected void onTick() {
            int distance = (int) get_ultrasonic_dist(ultrasonicSensor);
            if (distance>=200000000)
                distance = 23;
            int error = distance - targetDistance;
            double p_fix = (error * 10);
            int speed = (int) p_fix;

            if (p_fix >= 250) {
                speed = 250;
            }

            System.out.println("Distance: " + distance + " Speed: " + speed);

            if (distance>= targetDistance && distance<=targetDistance+4) {
                rotateLeft();
                Delay.msDelay(rotationTimeMs);
                distance = (int) get_ultrasonic_dist(ultrasonicSensor);
                if (distance > targetDistance) {
                    moveForward(speed);
                } else {
                    rotateRight();
                    Delay.msDelay(rotationTimeMs*2);
                    moveForward(speed);
                }
            } else {
                moveForward(speed);
            }
        }

        private void rotateLeft() {
            leftMotor.setSpeed(100);
            rightMotor.setSpeed(100);
            leftMotor.backward();
            rightMotor.forward();
        }

        private void rotateRight() {
            leftMotor.setSpeed(100);
            rightMotor.setSpeed(100);
            leftMotor.forward();
            rightMotor.backward();
        }

        private void moveForward(int speed) {
            leftMotor.setSpeed(speed);
            rightMotor.setSpeed(speed);
            leftMotor.forward();
            rightMotor.forward();
        }
    };

}
