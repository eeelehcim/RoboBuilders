package Connexion;

import jade.core.Agent;
import jade.core.behaviours.*;

import java.util.ArrayList;


public class DogukanFSMPro extends Agent {

    public static int product_points =0;
    public static int press_counts =0;
    public static int counter = 0;
    public static int arrayCounter = 0;

    public static int testN = -1;

    public static Boolean Block = false;
    public static boolean INIT = true;


    static ThreadedBehaviourFactory tbf = new ThreadedBehaviourFactory();
    public static FSMBehaviour fsm = new FSMBehaviour();

    static boolean isReseted = false;
    static boolean stopReading = false;


    public static SimpleBehaviour simpleBehaviour;


    public static boolean adaptStateBlue = false;
    public static boolean adaptStateGreen = false;
    public static boolean adaptStateRed = false;
    ArrayList<String> pair = new ArrayList<String>();

    public void print_pairs() {
/*
        System.out.println("Pairs: "+pair.size());

        for(String name:pair) {
            System.out.println(name+"cc");
        }

 */
    }

    @Override
    public void setup() {



        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                ParallelBehaviour parallelBehaviour = new ParallelBehaviour();

                simpleBehaviour = new SimpleBehaviour() {

                    final String[] sequence2 = new String[] {"Blue","Green","Red","Blue"};


                    final String[] sequence = new String[]{	"Blue","Green","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Green","Red","Blue","Blue","Red","Green","Green","Green","Blue","Red","Red","Green","Red","Green","Green","Red","Green","Red","Red","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Green","Red","Green","Green","Blue","Green","Green","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Red","Green","Blue","Green","Blue","Green","Blue","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Green",

                            "Green","Red","Green","Blue","Green","Red","Green","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Blue","Green","Green","Blue","Red","Blue","Red","Green","Red","Red","Red","Green","Red","Red","Red","Blue","Red","Green","Red","Red","Red","Red","Green","Green","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Green","Red","Green","Green","Red","Red","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Red","Green","Red","Blue","Red","Blue","Green","Red","Red","Green","Green","Green","Red",

                            "Green","Blue","Red","Green","Red","Blue","Blue","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Blue","Green","Red","Blue","Green","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Red","Red","Blue","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Red","Green","Green","Green","Green","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Blue","Green","Red","Green","Red","Green","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Blue","Green","Green","Green","Blue","Green","Red","Green","Red","Green","Green",

                            "Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Red","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Blue","Red","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Green","Red","Green","Red","Red","Green","Green","Blue","Blue","Red","Red","Blue","Red","Green","Green","Green","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Green","Blue","Blue","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Blue","Green","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Blue","Red","Red","Blue","Green",

                            "Red","Red","Red","Blue","Red","Green","Green","Blue","Blue","Green","Green","Green","Green","Red","Red","Green","Blue","Green","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Red","Blue","Red","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Green","Green","Green","Green","Green","Blue","Green","Red","Blue","Red","Blue","Blue","Green","Red","Green","Green","Red","Blue","Green","Red","Red","Green","Green","Blue","Red","Green","Blue","Blue","Green","Green","Blue","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Green","Green","Red","Green","Green","Blue","Red","Green","Green","Blue","Red","Green","Red","Red","Green","Red","Red","Red","Green","Green",

                            "Red","Red","Green","Red","Blue","Green","Red","Green","Green","Green","Blue","Blue","Green","Red","Blue","Green","Green","Red","Blue","Red","Green","Red","Red","Red","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Red","Green","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Red","Green","Green","Blue","Green","Green","Green","Blue","Green","Green","Blue","Green","Green","Blue","Red","Red","Red","Green","Red","Red","Red","Green","Red","Green","Red","Green","Red","Red","Green","Red","Red","Green","Blue","Red",

                            "Blue","Red","Red","Red","Red","Red","Blue","Red","Red","Red","Green","Red","Blue","Red","Blue","Blue","Red","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Blue","Red","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Green","Red","Blue","Blue","Blue","Green","Blue","Red","Red","Red","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Red","Green","Blue","Red","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Green","Blue","Blue","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Blue",

                            "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Blue","Red","Blue","Blue","Red","Red","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Green","Red","Green","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Red","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Blue","Blue","Blue","Red","Red","Green","Blue","Red","Red","Green","Blue","Red","Green","Green","Blue",

                            "Blue","Red","Green","Green","Blue","Blue","Red","Red","Red","Green","Red","Blue","Green","Green","Green","Blue","Green","Blue","Green","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Red","Green","Blue","Blue","Red","Red","Blue","Red","Red","Green","Blue","Green","Blue","Blue","Red","Blue","Red","Red","Green","Green","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Red","Blue","Green","Blue","Green","Red","Red","Blue","Green","Red","Blue","Green",

                            "Red","Red","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Green","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Blue","Green","Red","Green","Green","Red","Red","Green","Red","Blue","Green","Red","Green","Red","Red","Blue","Blue","Green","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Green","Red","Green","Red","Green","Red","Red","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Green","Green","Green","Red","Green","Green","Red","Blue","Green","Green","Green","Green","Green","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Blue","Blue",

                            "Red","Red","Green","Blue","Red","Red","Green","Green","Red","Blue","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Blue","Green","Green","Green","Blue","Green","Green","Blue","Blue","Green","Red","Red","Red","Blue","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Green","Green","Red","Blue","Green","Green","Red","Red","Blue","Green","Red","Blue","Red","Red","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Blue","Green","Blue",

                            "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Red","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Blue","Red","Green","Blue","Red","Blue","Red","Blue","Blue","Green","Red","Red","Red","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Red","Red","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Green","Blue","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Red","Red","Green","Green","Red","Red","Blue","Red","Red","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Green",

                            "Blue","Red","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Green","Green","Green","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Green","Green","Red","Red","Red","Green","Green","Red","Blue","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Red","Red","Blue","Green","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Green","Red",

                            "Blue","Red","Red","Green","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Blue","Blue","Green","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Red","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Green","Green","Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Red","Green","Green","Blue","Green","Green","Blue","Green","Blue","Blue","Red","Blue","Green","Red","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Blue","Blue","Green","Red","Red","Green","Blue",

                            "Red","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Red","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Red","Green","Blue","Blue","Red","Green","Red","Blue","Green","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Red","Red","Green","Green",

                            "Green","Red","Blue","Blue","Red","Blue","Blue","Red","Blue","Blue","Blue","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Blue","Red","Green","Red","Red","Blue","Red","Blue","Green","Green","Red","Red","Red","Red","Blue","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Green","Blue","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Green","Green","Blue","Blue","Red","Green","Red","Green","Green","Red","Red","Blue","Red","Red",

                            "Green","Green","Red","Green","Green","Red","Green","Blue","Blue","Green","Green","Blue","Red","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Blue","Green","Blue","Green","Blue","Red","Green","Green","Green","Blue","Green","Red","Blue","Green","Blue","Green","Green","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue",

                            "Blue","Green","Blue","Red","Blue","Blue","Red","Green","Red","Red","Red","Green","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Green","Blue","Blue","Red","Red","Red","Red","Red","Green","Red","Green","Red","Red","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Green","Green","Red","Red","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Red","Green","Red","Blue","Red","Green","Blue","Green","Blue","Red","Red","Blue","Blue","Green","Red","Red","Red","Red","Green","Red","Blue","Green","Blue","Blue","Red","Blue",

                            "Green","Red","Red","Green","Red","Red","Blue","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Blue","Red","Red","Blue","Red","Blue","Red","Red","Green","Blue","Blue","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Red","Red","Blue","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Blue","Red",

                            "Red","Green","Red","Green","Blue","Green","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Green","Green","Blue","Green","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Red","Green","Red","Green","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Blue","Blue","Green","Red","Red","Green","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Green","Green","Green","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Green","Green","Red","Red","Blue","Red","Blue","Blue","Red","Green","Green","Blue",

                            "Green","Red","Blue","Red","Green","Green","Red","Blue","Green","Green","Green","Red","Red","Blue","Red","Green","Blue","Red","Green","Green","Blue","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Red","Red","Blue","Green","Red","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Blue","Red","Green","Green","Green","Red","Red","Red","Red","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Red","Green","Red","Green","Red","Blue","Green","Green",

                            "Blue","Red","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Blue","Green","Green","Green","Green","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Blue","Red","Red","Red","Red","Blue","Green","Red","Red","Blue","Green","Green","Green","Red","Red","Blue","Green","Green","Red","Blue","Red","Red","Green","Blue","Red","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Red","Green","Green","Green","Green","Green","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue",

                            "Red","Green","Green","Red","Red","Red","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Green","Red","Blue","Green","Green","Blue","Green","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Green","Red","Blue","Red","Blue","Green","Green","Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Blue","Red","Green","Green","Green","Blue","Green","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Green","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Blue","Red",

                            "Blue","Green","Green","Red","Red","Blue","Green","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Red","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Blue","Red","Blue","Green","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Red","Green","Red","Blue","Red","Green","Green","Red","Red","Green","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Green","Green","Green","Blue","Blue","Green","Green","Red","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Blue","Blue","Blue","Red",

                            "Red","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Blue","Green","Blue","Red","Red","Green","Blue","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Green","Blue","Blue","Red","Red","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Red","Red","Green","Green","Green","Blue","Blue","Blue","Green","Red","Blue","Red","Red","Red","Red","Green","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Blue","Red","Green","Red","Blue","Blue","Red","Red","Green","Red","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Red","Blue","Red",

                            "Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Red","Green","Green","Red","Red","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Green","Green","Blue","Red","Green","Red","Red","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Red","Red","Red","Red","Red","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Green","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Green",

                            "Red","Red","Green","Blue","Green","Blue","Red","Green","Blue","Green","Green","Green","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Red","Red","Green","Green","Blue","Blue","Blue","Blue","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Green","Green","Blue","Blue",

                            "Red","Red","Red","Blue","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Blue","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Green","Green","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Blue","Red","Blue","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Red","Green","Blue","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Red","Red","Red","Green","Blue","Green","Blue","Green","Red","Red","Green","Red","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Red","Red","Green","Blue","Green","Red","Green",

                            "Green","Green","Blue","Red","Red","Green","Blue","Red","Green","Blue","Red","Blue","Green","Blue","Green","Green","Green","Blue","Green","Blue","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Red","Red","Green","Green","Red","Green","Blue","Green","Red","Green","Red","Green","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Green","Red","Green","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Green","Blue","Green","Blue","Green","Blue","Red","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Red","Blue","Blue","Blue","Green","Blue","Green","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Red","Red","Green","Red","Red","Red","Blue",

                            "Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Blue","Blue","Blue","Green","Blue","Red","Red","Green","Green","Blue","Blue","Red","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Red","Green","Blue","Blue","Green","Red","Red","Blue","Red","Red","Blue","Blue","Red","Green","Green","Red","Blue","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Green","Blue","Blue","Red","Red","Green","Green","Red","Green","Blue","Blue","Green",

                            "Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Red","Red","Red","Red","Green","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Red","Red","Red","Green","Red","Blue","Blue","Green","Green","Green","Green","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Green","Red","Green","Green","Blue","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Green","Green","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Green","Red","Red","Blue","Red","Red","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue"};
                    String state;

                    @Override
                    public void action() {

                        if (!stopReading) {
                            state = sequence[arrayCounter];

                            addBehaviour(new OneShotBehaviour() {
                                @Override
                                public void action() {
                                    if (state.equals("Blue")) {
                                        adaptStateBlue = true;
                                   //   System.out.println(arrayCounter+"Blue Blue Blue Blue Blue Blue");
                                    }
                                    if (state.equals("Green")) {
                                        adaptStateGreen = true;
                              //               System.out.println(arrayCounter+"Green Green Green Green Green Green");
                                    }
                                    if (state.equals("Red")) {
                               //              System.out.println(arrayCounter+"RED RED RED RED RED RED RED RED RED");
                                        adaptStateRed = true;
                                    }
                                    try {
                                        Thread.sleep(50);
                                    } catch (InterruptedException e) {
                                        throw new RuntimeException(e);
                                    }

//                                    System.out.println("---adapted---");
                                }
                            });
                            arrayCounter++;
                         //   if(arrayCounter == sequence.length)
                           //     arrayCounter = 0;
                        }

                        if (arrayCounter%30==0){

                            testN++;
                            System.out.println(" TestN= "+testN+" "+" ProductPoints= "+product_points+" PressCounts= "+press_counts);
                            product_points=0;
                            press_counts=0;
                        }

                    }

                    @Override
                    public boolean done() {
                        return false;
                    }
                };



                if (INIT){
                    addBehaviour(parallelBehaviour);
                    addBehaviour(runOnce);
                    parallelBehaviour.addSubBehaviour(simpleBehaviour);
                    parallelBehaviour.addSubBehaviour(fsm);
                    INIT = false;
                }


            }

        });
    }


    OneShotBehaviour Resetpos = new OneShotBehaviour() {


        @Override
        public void action() {
       //     System.out.println("Initc");

            print_pairs();
        }



        @Override
        public int onEnd() {
            if (adaptStateRed) {
                return 3;
            } else if (adaptStateBlue)
                return 2;
            else if (adaptStateGreen)
                return 1;
            else
                return 0;
        }
    };

    OneShotBehaviour FirstGreen = new OneShotBehaviour() {
        @Override
        public void action() {
    //        System.out.println("First Green");
            pair.add("Green");
            print_pairs();
            if (adaptStateRed || adaptStateBlue) {
     //           System.out.println("EJECT");

                if (pair.size()>0 && pair.indexOf("Blue")>0)
                pair.remove(pair.indexOf("Blue"));

            } else {
    //            System.out.println("PRESS");
              //  pair.clear();
            }

            print_pairs();
        }

        @Override
        public int onEnd() {
            if (adaptStateGreen) {
                return 2;
            } else if (adaptStateRed)
                return 1;
            else
                return 0;
        }
    };

    OneShotBehaviour FirstBlue = new OneShotBehaviour() {
        @Override
        public void action() {
   //         System.out.println("First Blue");

            if (adaptStateRed || adaptStateGreen) {
                print_pairs();
    //            System.out.println("EJECT");

                if (pair.size()>0 && pair.indexOf("Green")>0)
                pair.remove(pair.indexOf("Green"));

            } else {
   //             System.out.println("PRESS");
                pair.add("Blue");
            }


            print_pairs();
        }

        @Override
        public int onEnd() {
            if (adaptStateBlue) {
                return 2;
            } else if (adaptStateRed)
                return 1;
            else
                return 0;
        }
    };

    OneShotBehaviour FirstRed = new OneShotBehaviour() {
        @Override
        public void action() {
    //        System.out.println("First Red");
            stopReading = true;
            adaptStateRed = false;

    //        System.out.println("PRESS");
            pair.add("Red");
            stopReading = false;

            print_pairs();
        }
    };

    OneShotBehaviour OtherPress = new OneShotBehaviour() {
        @Override
        public void action() {
     //       System.out.println("OtherPress");
            stopReading = true;

            print_pairs();
     //       System.out.println("PRESS");
            print_pairs();
    //        System.out.println("EJECT");
            print_pairs();

            if (pair.size()>1){
                print_pairs();

                if ((pair.get(0).equals("Red") && (pair.get(1).equals("Red")))){
                    product_points+=4;
                }

                else if ( (pair.get(0).equals("Red") && (pair.get(1).equals("Blue"))) || (pair.get(0).equals("Red") && (pair.get(1).equals("Green"))))
                {
                    product_points+=2;
                }

                else if ( (pair.get(0).equals("Blue") && (pair.get(1).equals("Red"))) || (pair.get(0).equals("Green") && (pair.get(1).equals("Red"))))
                {
                    product_points+=2;
                }

                else if ( (pair.get(0).equals("Blue") && (pair.get(1).equals("Blue"))) || (pair.get(0).equals("Green") && (pair.get(1).equals("Green"))))
                {
                    product_points+=1;
                }

                press_counts+=1;

      //          System.out.println(arrayCounter);
            pair.clear();
            }




            if (adaptStateBlue)
                adaptStateBlue = false;
            if (adaptStateGreen)
                adaptStateGreen = false;
            if (adaptStateRed)
                adaptStateRed = false;

            stopReading = false;


        }
    };


    OneShotBehaviour runOnce = new OneShotBehaviour() {
        @Override
        public void action() {

            System.out.println("Register Your States");

            fsm.registerFirstState(Resetpos, "init");
            fsm.registerState(FirstGreen, "first_green");
            fsm.registerState(FirstBlue, "first_blue");
            fsm.registerState(FirstRed, "first_red");
            fsm.registerState(OtherPress, "other_press");


            fsm.registerTransition("init", "init", 0);
            fsm.registerTransition("init", "first_green", 1);
            fsm.registerTransition("init", "first_blue", 2);
            fsm.registerTransition("init", "first_red", 3);


            fsm.registerTransition("first_green", "init", 0);
            fsm.registerTransition("first_green", "first_red", 1);
            fsm.registerTransition("first_green", "other_press", 2);

            fsm.registerTransition("first_blue", "init", 0);
            fsm.registerTransition("first_blue", "first_red", 1);
            fsm.registerTransition("first_blue", "other_press", 2);

            fsm.registerDefaultTransition("first_red", "other_press");
            fsm.registerDefaultTransition("other_press", "init");


        }


    };

}