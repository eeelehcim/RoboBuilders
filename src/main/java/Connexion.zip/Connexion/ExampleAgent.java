package Connexion;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SequentialBehaviour;
import jade.core.behaviours.TickerBehaviour;

public class ExampleAgent extends Agent {



        @Override
        protected void setup() {
            System.out.println("local name"+getAID().getLocalName());
            System.out.println("GloBal name"+getAID().getName());

            addBehaviour(OneShot);
            addBehaviour(Ticker);
            addBehaviour(sensorValues);

            SequentialBehaviour sequentialBehaviour = new SequentialBehaviour(this);

            sequentialBehaviour.addSubBehaviour(turnOnMotor);
            sequentialBehaviour.addSubBehaviour(turn90degrees);
            sequentialBehaviour.addSubBehaviour(turnOffTheMotors);


            addBehaviour(sequentialBehaviour); // do not forget to add this to the queue.








        }



        OneShotBehaviour OneShot = new OneShotBehaviour() {
            @Override
            public void action() {
                //        System.out.println("First Green");
                System.out.println("This is a one-shot event");
            }

            @Override
            public int onEnd() {
                System.out.println("One shot event is ending");
                return  0;
            }
        };


    OneShotBehaviour turnOnMotor = new OneShotBehaviour() {
        @Override
        public void action() {

            System.out.println("Motors are turned on 1");

            block(1000);

                 }




    };

    OneShotBehaviour turn90degrees = new OneShotBehaviour() {
        @Override
        public void action() {

            System.out.println("Turn 90 degrees 2 ");

            block(1000);
        }
    };

    OneShotBehaviour turnOffTheMotors = new OneShotBehaviour() {
        @Override
        public void action() {

            System.out.println("Turn off the motors 3");

            block(1000);
        }
    };


    TickerBehaviour Ticker = new TickerBehaviour(this, 1000) {
            @Override
            protected void onTick() {
                System.out.println("Ticker behaviour triggered each second");

            }

    };


        ///////////////

    CyclicBehaviour sensorValues = new CyclicBehaviour() {
        public void action() {
            System.out.println("Read sensor values");
            block(500); // if you do not use this then it stops the other behaviours.

            }




    };




}

