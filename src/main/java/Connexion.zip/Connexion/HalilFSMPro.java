package Connexion;

import jade.core.Agent;
import jade.core.behaviours.FSMBehaviour;
import jade.core.behaviours.OneShotBehaviour;

import java.util.ArrayList;




enum Color {
    Red(0), Blue(1), Green(2);

    public final int val;

    Color(int val){
        this.val = val;
    }
}

public class HalilFSMPro extends Agent {

    public static int product_points =0;
    public static int press_counts =0;
    public static int testN = -1;

    public void print_pairs() {

        //        System.out.println("Pairs: "+pair.size());

        for(String name:pair) {
            //            System.out.println(name+"cc");
        }


    }







    FSMBehaviour fsm = new FSMBehaviour();
    Color currentColor = null;
    int chance = 1;
    boolean IsPressed = false;


    ArrayList<String> pair = new ArrayList<String>();



    OneShotBehaviour Read = new OneShotBehaviour() {
        String[] sequence2 = new String[]{"Red","Red","Green","Green","Blue","Green","Red","Blue","Red","Blue","Blue","Blue"};

        final String[] sequence = new String[]{	"Blue","Green","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Green","Red","Blue","Blue","Red","Green","Green","Green","Blue","Red","Red","Green","Red","Green","Green","Red","Green","Red","Red","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Green","Red","Green","Green","Blue","Green","Green","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Red","Green","Blue","Green","Blue","Green","Blue","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Green",

                "Green","Red","Green","Blue","Green","Red","Green","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Blue","Green","Green","Blue","Red","Blue","Red","Green","Red","Red","Red","Green","Red","Red","Red","Blue","Red","Green","Red","Red","Red","Red","Green","Green","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Green","Red","Green","Green","Red","Red","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Red","Green","Red","Blue","Red","Blue","Green","Red","Red","Green","Green","Green","Red",

                "Green","Blue","Red","Green","Red","Blue","Blue","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Blue","Green","Red","Blue","Green","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Red","Red","Blue","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Red","Green","Green","Green","Green","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Blue","Green","Red","Green","Red","Green","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Blue","Green","Green","Green","Blue","Green","Red","Green","Red","Green","Green",

                "Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Red","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Blue","Red","Red","Blue","Red","Green","Blue","Red","Blue","Blue","Red","Green","Red","Green","Red","Red","Green","Green","Blue","Blue","Red","Red","Blue","Red","Green","Green","Green","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Green","Blue","Blue","Green","Red","Red","Blue","Blue","Green","Blue","Blue","Blue","Green","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Blue","Red","Red","Blue","Green",

                "Red","Red","Red","Blue","Red","Green","Green","Blue","Blue","Green","Green","Green","Green","Red","Red","Green","Blue","Green","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Red","Blue","Red","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Green","Green","Green","Green","Green","Blue","Green","Red","Blue","Red","Blue","Blue","Green","Red","Green","Green","Red","Blue","Green","Red","Red","Green","Green","Blue","Red","Green","Blue","Blue","Green","Green","Blue","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Green","Green","Red","Green","Green","Blue","Red","Green","Green","Blue","Red","Green","Red","Red","Green","Red","Red","Red","Green","Green",

                "Red","Red","Green","Red","Blue","Green","Red","Green","Green","Green","Blue","Blue","Green","Red","Blue","Green","Green","Red","Blue","Red","Green","Red","Red","Red","Blue","Blue","Green","Blue","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Red","Green","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Red","Green","Green","Blue","Green","Green","Green","Blue","Green","Green","Blue","Green","Green","Blue","Red","Red","Red","Green","Red","Red","Red","Green","Red","Green","Red","Green","Red","Red","Green","Red","Red","Green","Blue","Red",

                "Blue","Red","Red","Red","Red","Red","Blue","Red","Red","Red","Green","Red","Blue","Red","Blue","Blue","Red","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Blue","Red","Blue","Blue","Green","Blue","Green","Green","Green","Green","Red","Green","Red","Blue","Blue","Blue","Green","Blue","Red","Red","Red","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Red","Green","Blue","Red","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Green","Blue","Blue","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Blue",

                "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Blue","Red","Blue","Blue","Red","Red","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Green","Red","Green","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Red","Blue","Blue","Blue","Blue","Green","Blue","Red","Green","Blue","Blue","Blue","Red","Red","Green","Blue","Red","Red","Green","Blue","Red","Green","Green","Blue",

                "Blue","Red","Green","Green","Blue","Blue","Red","Red","Red","Green","Red","Blue","Green","Green","Green","Blue","Green","Blue","Green","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Red","Green","Blue","Blue","Red","Red","Blue","Red","Red","Green","Blue","Green","Blue","Blue","Red","Blue","Red","Red","Green","Green","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Red","Blue","Green","Blue","Green","Red","Red","Blue","Green","Red","Blue","Green",

                "Red","Red","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Green","Green","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Blue","Green","Red","Green","Green","Red","Red","Green","Red","Blue","Green","Red","Green","Red","Red","Blue","Blue","Green","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Green","Red","Green","Red","Green","Red","Red","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Green","Green","Green","Red","Green","Green","Red","Blue","Green","Green","Green","Green","Green","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Blue","Blue",

                "Red","Red","Green","Blue","Red","Red","Green","Green","Red","Blue","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Blue","Green","Green","Green","Blue","Green","Green","Blue","Blue","Green","Red","Red","Red","Blue","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Red","Green","Blue","Green","Green","Red","Red","Blue","Blue","Green","Green","Green","Red","Blue","Green","Green","Red","Red","Blue","Green","Red","Blue","Red","Red","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Blue","Red","Blue","Green","Blue",

                "Blue","Green","Green","Red","Green","Red","Red","Red","Blue","Red","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Blue","Red","Green","Blue","Red","Blue","Red","Blue","Blue","Green","Red","Red","Red","Green","Red","Red","Red","Green","Blue","Red","Green","Green","Red","Red","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Green","Blue","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Red","Red","Green","Green","Red","Red","Blue","Red","Red","Blue","Green","Red","Red","Green","Red","Green","Blue","Red","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Green",

                "Blue","Red","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Blue","Blue","Blue","Blue","Red","Red","Red","Blue","Blue","Red","Red","Green","Green","Blue","Red","Green","Red","Green","Red","Green","Red","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Green","Green","Green","Blue","Blue","Blue","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Green","Green","Red","Red","Red","Green","Green","Red","Blue","Red","Red","Red","Blue","Red","Blue","Red","Blue","Red","Green","Green","Red","Red","Blue","Green","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Green","Red",

                "Blue","Red","Red","Green","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Green","Blue","Blue","Green","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Red","Blue","Blue","Red","Red","Green","Blue","Blue","Blue","Green","Green","Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Red","Green","Green","Blue","Green","Green","Blue","Green","Blue","Blue","Red","Blue","Green","Red","Blue","Green","Red","Blue","Blue","Green","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Blue","Blue","Green","Red","Red","Green","Blue",

                "Red","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Red","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Blue","Green","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Green","Green","Green","Red","Blue","Blue","Red","Blue","Green","Red","Blue","Red","Green","Blue","Blue","Red","Green","Red","Blue","Green","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Green","Red","Red","Green","Green",

                "Green","Red","Blue","Blue","Red","Blue","Blue","Red","Blue","Blue","Blue","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Green","Green","Red","Green","Green","Blue","Red","Green","Red","Red","Blue","Red","Blue","Green","Green","Red","Red","Red","Red","Blue","Blue","Red","Green","Blue","Green","Green","Red","Blue","Red","Blue","Blue","Green","Blue","Blue","Blue","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Green","Blue","Blue","Green","Blue","Green","Red","Blue","Blue","Blue","Red","Green","Red","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Blue","Green","Green","Blue","Blue","Red","Green","Red","Green","Green","Red","Red","Blue","Red","Red",

                "Green","Green","Red","Green","Green","Red","Green","Blue","Blue","Green","Green","Blue","Red","Green","Red","Green","Red","Red","Red","Green","Blue","Blue","Green","Blue","Red","Green","Green","Blue","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Red","Green","Blue","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Blue","Green","Blue","Green","Blue","Red","Green","Green","Green","Blue","Green","Red","Blue","Green","Blue","Green","Green","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue",

                "Blue","Green","Blue","Red","Blue","Blue","Red","Green","Red","Red","Red","Green","Green","Blue","Blue","Green","Green","Red","Red","Red","Red","Green","Blue","Blue","Red","Red","Red","Red","Red","Green","Red","Green","Red","Red","Blue","Red","Red","Red","Green","Green","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Red","Green","Red","Green","Green","Red","Green","Green","Red","Red","Red","Red","Blue","Green","Red","Green","Blue","Red","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Red","Green","Red","Blue","Red","Green","Blue","Green","Blue","Red","Red","Blue","Blue","Green","Red","Red","Red","Red","Green","Red","Blue","Green","Blue","Blue","Red","Blue",

                "Green","Red","Red","Green","Red","Red","Blue","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Blue","Red","Green","Red","Red","Blue","Blue","Red","Red","Green","Red","Blue","Blue","Red","Green","Blue","Red","Red","Blue","Red","Blue","Red","Red","Green","Blue","Blue","Red","Blue","Blue","Red","Blue","Green","Green","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Red","Red","Blue","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Red","Blue","Green","Blue","Red","Red","Blue","Green","Blue","Red",

                "Red","Green","Red","Green","Blue","Green","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Green","Green","Blue","Green","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Blue","Red","Green","Red","Green","Green","Blue","Blue","Green","Blue","Red","Blue","Green","Blue","Blue","Green","Red","Red","Green","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Blue","Red","Red","Red","Green","Blue","Blue","Red","Green","Green","Green","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Green","Green","Red","Red","Blue","Red","Blue","Blue","Red","Green","Green","Blue",

                "Green","Red","Blue","Red","Green","Green","Red","Blue","Green","Green","Green","Red","Red","Blue","Red","Green","Blue","Red","Green","Green","Blue","Red","Red","Blue","Red","Blue","Red","Blue","Red","Red","Blue","Blue","Green","Blue","Red","Green","Red","Blue","Red","Red","Blue","Green","Red","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Green","Red","Blue","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Blue","Red","Green","Green","Green","Red","Red","Red","Red","Green","Green","Blue","Blue","Green","Red","Blue","Blue","Green","Green","Blue","Blue","Blue","Blue","Blue","Green","Green","Green","Red","Red","Green","Red","Green","Red","Blue","Green","Green",

                "Blue","Red","Red","Green","Blue","Green","Blue","Red","Red","Green","Blue","Green","Blue","Green","Green","Green","Green","Blue","Blue","Red","Red","Red","Green","Blue","Green","Blue","Red","Blue","Red","Red","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Blue","Red","Red","Green","Blue","Green","Red","Blue","Red","Red","Red","Red","Blue","Green","Red","Red","Blue","Green","Green","Green","Red","Red","Blue","Green","Green","Red","Blue","Red","Red","Green","Blue","Red","Red","Blue","Green","Blue","Green","Blue","Blue","Red","Red","Green","Green","Green","Green","Green","Red","Green","Blue","Blue","Blue","Blue","Blue","Blue",

                "Red","Green","Green","Red","Red","Red","Blue","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Green","Red","Blue","Green","Green","Blue","Green","Green","Red","Blue","Blue","Red","Blue","Red","Green","Blue","Red","Green","Red","Blue","Red","Blue","Green","Green","Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Green","Blue","Green","Blue","Red","Blue","Green","Green","Blue","Red","Green","Blue","Red","Green","Green","Green","Blue","Green","Blue","Blue","Green","Green","Blue","Blue","Green","Red","Blue","Green","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Blue","Red",

                "Blue","Green","Green","Red","Red","Blue","Green","Red","Red","Red","Green","Blue","Blue","Blue","Red","Green","Red","Green","Red","Red","Blue","Blue","Blue","Blue","Red","Blue","Red","Blue","Green","Blue","Red","Green","Blue","Blue","Green","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Blue","Green","Red","Red","Green","Red","Blue","Red","Green","Green","Red","Red","Green","Blue","Green","Blue","Blue","Blue","Green","Red","Red","Red","Blue","Red","Green","Green","Green","Green","Green","Blue","Blue","Green","Green","Red","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Blue","Red","Blue","Blue","Blue","Red",

                "Red","Red","Red","Green","Red","Red","Red","Red","Blue","Red","Blue","Green","Blue","Red","Red","Green","Blue","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Green","Blue","Blue","Red","Red","Red","Red","Blue","Red","Red","Blue","Blue","Red","Blue","Blue","Red","Red","Green","Green","Green","Blue","Blue","Blue","Green","Red","Blue","Red","Red","Red","Red","Green","Red","Green","Blue","Green","Blue","Green","Blue","Blue","Red","Blue","Blue","Green","Red","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Blue","Red","Green","Red","Blue","Blue","Red","Red","Green","Red","Blue","Red","Green","Green","Blue","Red","Blue","Green","Red","Blue","Red","Blue","Red",

                "Blue","Red","Blue","Red","Blue","Red","Red","Green","Blue","Red","Red","Green","Green","Red","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Blue","Red","Green","Green","Red","Red","Red","Green","Green","Green","Red","Green","Red","Green","Blue","Blue","Blue","Blue","Red","Green","Green","Green","Red","Blue","Green","Red","Green","Red","Blue","Green","Blue","Blue","Green","Green","Green","Blue","Red","Green","Red","Red","Red","Blue","Red","Blue","Blue","Green","Green","Blue","Blue","Red","Red","Red","Red","Red","Red","Blue","Red","Red","Green","Red","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Green","Red","Red","Blue","Blue","Red","Red","Blue","Blue","Green",

                "Red","Red","Green","Blue","Green","Blue","Red","Green","Blue","Green","Green","Green","Red","Green","Blue","Green","Green","Blue","Blue","Blue","Green","Blue","Green","Blue","Blue","Blue","Green","Green","Green","Blue","Red","Blue","Blue","Blue","Blue","Red","Red","Red","Green","Green","Red","Red","Green","Green","Blue","Blue","Blue","Blue","Red","Blue","Blue","Blue","Blue","Blue","Red","Blue","Green","Green","Green","Green","Red","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Red","Blue","Green","Blue","Blue","Blue","Blue","Red","Red","Green","Red","Green","Red","Green","Blue","Green","Red","Red","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Green","Green","Blue","Blue",

                "Red","Red","Red","Blue","Green","Green","Red","Red","Green","Blue","Blue","Blue","Green","Blue","Blue","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Green","Green","Green","Green","Blue","Red","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Red","Red","Red","Blue","Red","Green","Red","Green","Blue","Blue","Red","Blue","Red","Red","Red","Blue","Blue","Blue","Red","Blue","Red","Green","Blue","Green","Red","Red","Green","Green","Green","Blue","Green","Green","Red","Red","Red","Green","Blue","Green","Blue","Green","Red","Red","Green","Red","Red","Red","Red","Red","Green","Blue","Red","Red","Red","Green","Green","Blue","Red","Red","Green","Blue","Green","Red","Green",

                "Green","Green","Blue","Red","Red","Green","Blue","Red","Green","Blue","Red","Blue","Green","Blue","Green","Green","Green","Blue","Green","Blue","Red","Green","Green","Green","Red","Green","Blue","Green","Red","Red","Red","Green","Green","Red","Green","Blue","Green","Red","Green","Red","Green","Red","Blue","Blue","Green","Blue","Blue","Green","Blue","Blue","Green","Red","Green","Green","Blue","Red","Green","Blue","Red","Blue","Red","Red","Green","Blue","Green","Blue","Green","Blue","Red","Red","Red","Green","Red","Green","Blue","Red","Red","Red","Red","Blue","Blue","Blue","Green","Blue","Green","Blue","Red","Red","Blue","Red","Green","Green","Blue","Blue","Red","Red","Green","Red","Red","Red","Blue",

                "Blue","Blue","Blue","Blue","Green","Red","Blue","Green","Red","Green","Blue","Green","Red","Blue","Green","Green","Green","Blue","Blue","Blue","Green","Blue","Red","Red","Green","Green","Blue","Blue","Red","Blue","Red","Blue","Blue","Red","Red","Blue","Green","Green","Blue","Red","Blue","Blue","Blue","Red","Blue","Green","Red","Red","Blue","Red","Blue","Red","Blue","Blue","Blue","Blue","Green","Green","Red","Red","Green","Blue","Blue","Green","Red","Red","Blue","Red","Red","Blue","Blue","Red","Green","Green","Red","Blue","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Red","Red","Blue","Green","Blue","Blue","Red","Red","Green","Green","Red","Green","Blue","Blue","Green",

                "Red","Green","Red","Green","Blue","Red","Blue","Green","Red","Red","Red","Red","Red","Green","Green","Blue","Green","Blue","Green","Green","Blue","Blue","Red","Red","Blue","Blue","Red","Red","Red","Red","Green","Red","Blue","Blue","Green","Green","Green","Green","Green","Green","Blue","Green","Green","Green","Green","Green","Red","Green","Red","Green","Green","Blue","Blue","Red","Red","Green","Blue","Green","Green","Blue","Blue","Green","Green","Red","Green","Red","Red","Blue","Red","Green","Red","Blue","Green","Red","Red","Blue","Red","Red","Red","Green","Red","Green","Blue","Blue","Red","Green","Red","Green","Red","Green","Green","Blue","Green","Green","Blue","Red","Red","Blue","Green","Red","Blue"};

        int currentIndex = 0;
        Color color = null;




        @Override
        public void action() {
            while (currentIndex < sequence.length) {
             //   System.out.println(currentIndex);

                if (currentIndex%30==0){

                    testN++;
                    System.out.println("TestN= "+testN+" "+" ProductPoints= "+product_points+" PressCounts= "+press_counts);
                    product_points=0;
                    press_counts=0;
                }






                switch(sequence[currentIndex++]){
                    case "Red":
                        color=Color.Red;
                        return;
                    case "Blue":
                        color=Color.Blue;
                        return;
                    case "Green":
                        color=Color.Green;
                        return;
                }
            }





            if(currentIndex >= sequence.length){



                block();
            }







        }

        @Override
        public int onEnd() {
       //     System.out.println("Color READ:" + color );
            return color.val;
        }
    };

    OneShotBehaviour Red = new OneShotBehaviour() {
        @Override
        public void action() {

            if (currentColor != null && currentColor != Color.Red) {
                // Eger gelen renk kirmizi ise ama elimizde kirmizi disinda birsey var hemen ejectliyoruz
                Eject();

                if (pair.size()>0 && pair.indexOf(currentColor)>0)
                    pair.remove(pair.indexOf(currentColor));

                currentColor = null;

                print_pairs();

                //          System.out.println("Red 1");
            }

            if (currentColor == null) {
                // Haznede hicbir renk yoksa ve gelen red ise hemen press1 ile basiyoruz
                currentColor = Color.Red;
                Press1();
                pair.add("Red");

                print_pairs();

                //          System.out.println("Red 2 - added");

            } else {
                // eger elimize kirmizi geldiysa ve elimizde kirmizi varsa build edip ejectliyoruz

                //         System.out.println("Red 3 - to Build and Eject");

                pair.add("Red");

                BuildAndEject();
                currentColor = null;

                print_pairs();



            }
        }
    };

    OneShotBehaviour Blue = new OneShotBehaviour() {
        @Override
        public void action() {
            if (currentColor == null) {
                // eger elimizde hicbirsey yoksa maviyi aliyoruz ama basmiyoruz
                currentColor = Color.Blue;

                pair.add("Blue");

                print_pairs();

                //         System.out.println("Blue 1");

            } else if (currentColor == Color.Red) {
                // eger elimizde kirmizi var ve mavi geldiyse
                if (chance != 0) { // atma sansimiz var ise atiyoruz
                    chance--;
                    Eject();

                    if (pair.size()>0 && pair.indexOf("Blue")>0)
                        pair.remove(pair.indexOf("Blue"));

                    print_pairs();

                    //         System.out.println("Blue 2");

                } else {
                    // atma sansimiz yoksa birlestirip urun buildliyoruz

                    pair.add("Blue");
                    BuildAndEject();

                    print_pairs();

                    //             System.out.println("Blue 3");


                }
            } else if (currentColor == Color.Blue) {
                // Elimizde mavi varsa ve mavi geldiysa urun buildliyoruz

                pair.add("Blue");
                BuildAndEject();

                //          System.out.println("Blue 4");
            } else {
                // Elimize yesil varsa ve mavi gelirse ejectliyoruz basmiyoruz hicbirsekilde artik yeni rengimiz Mavi
                Eject();

                if (pair.size()>0 && pair.indexOf(currentColor)>0)
                        pair.remove(pair.indexOf(currentColor));

                currentColor = Color.Blue;

                pair.add("Blue");

                print_pairs();

                //        System.out.println("Blue 5");

            }
        }
    };

    OneShotBehaviour Green = new OneShotBehaviour() {
        @Override
        public void action() {
            if (currentColor == null) {
                // eger elimizde hicbirsey yoksa yesili aliyoruz ama basmiyoruz
                currentColor = Color.Green;
                pair.add("Green");

                print_pairs();

                //            System.out.println("Green 1");

            } else if (currentColor == Color.Red) {
                // eger elimizde kirmizi var ve yesil geldiyse
                if (chance != 0) { // atma sansimiz var ise atiyoruz
                    chance--;
                    Eject();

                    //                 System.out.println("Green 2");

                    if (pair.size()>0 && pair.indexOf("Green")>0)
                        pair.remove(pair.indexOf("Green"));


                    print_pairs();

                    //            System.out.println("Green 3");

                } else {
                    // atma sansimiz yoksa birlestirip urun buildliyoruz
                    pair.add("Green");
                    BuildAndEject();

                    print_pairs();

                    //            System.out.println("Green 4");
                }
            } else if (currentColor == Color.Green) {
                // Elimizde mavi varsa ve yesil geldiysa urun buildliyoruz
                print_pairs();
                pair.add("Green");
                //             System.out.println("Green 5");
                BuildAndEject();


            } else {
                // Elimizde mavi varsa ve yesil gelirse ejectliyoruz basmiyoruz hicbirsekilde artik yeni rengimiz yesil
                Eject();

                if (pair.size()>0 && pair.indexOf(currentColor)>0)
                    pair.remove(pair.indexOf("Blue"));

                currentColor = Color.Green;

                print_pairs();

                //              System.out.println("Green 6");
            }
        }
    };


    @Override
    protected void setup() {
        System.out.println("local name" + getAID().getLocalName());
        System.out.println("GloBal name" + getAID().getName());

        fsm.registerDefaultTransition("Red","Read");
        fsm.registerDefaultTransition("Blue","Read");
        fsm.registerDefaultTransition("Green","Read");

        fsm.registerTransition("Read","Red",Color.Red.val);
        fsm.registerTransition("Read","Blue",Color.Blue.val);
        fsm.registerTransition("Read","Green",Color.Green.val);

        fsm.registerFirstState(Read, "Read");
        fsm.registerLastState(Read, "ReadLast");
        fsm.registerState(Blue, "Blue");
        fsm.registerState(Green, "Green");
        fsm.registerState(Red, "Red");
        addBehaviour(fsm);

    }


    @Override
    protected void takeDown() {

    }

    public void Eject() {
        //   System.out.println("Eject");
    }

    public void Press1() {
        IsPressed = true;
        //       System.out.println("Press1");
    }

    public void Press2() {
//         System.out.println("Press2");
    }

    public void BuildAndEject() {
        //       System.out.println("BuildAndEject Pairs" );
        print_pairs();



        currentColor = null;
        chance = 0;
        if (!IsPressed) {
            Press1();
        }
        IsPressed=false;
        Press2();
        Eject();

        if (pair.size()>1){
            print_pairs();

            if ((pair.get(0).equals("Red") && (pair.get(1).equals("Red")))){
                product_points+=4;
            }

            else if ( (pair.get(0).equals("Red") && (pair.get(1).equals("Blue"))) || (pair.get(0).equals("Red") && (pair.get(1).equals("Green"))))
            {
                product_points+=2;
            }

            else if ( (pair.get(0).equals("Blue") && (pair.get(1).equals("Red"))) || (pair.get(0).equals("Green") && (pair.get(1).equals("Red"))))
            {
                product_points+=2;
            }

            else if ( (pair.get(0).equals("Blue") && (pair.get(1).equals("Blue"))) || (pair.get(0).equals("Green") && (pair.get(1).equals("Green"))))
            {
                product_points+=1;
            }

            press_counts+=1;

            //          System.out.println(arrayCounter);
            pair.clear();
        }














    }


}
