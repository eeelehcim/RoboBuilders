package Connexion;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

import static jade.lang.acl.ACLMessage.INFORM;

public class AgentMain extends Agent {
    @Override
    protected void setup() {
            System.out.println("local name Main"+getAID().getLocalName());
            System.out.println("GloBal name Main"+getAID().getName());
            addBehaviour(new CyclicBehaviour() {
                @Override
                public void action() {
                    try {
                        //    System.out.println("asd");
                        ACLMessage Message=receive();
                        if (Message!=null) {
                            System.out.println("Agent Main Received: "+Message.getContent());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                }
            });

            addBehaviour(eachOneSec);

        }



    TickerBehaviour eachOneSec = new TickerBehaviour(this, 1000) {
        @Override
        protected void onTick() {
            //   System.out.println("Tick From the Robot Agent");
            ACLMessage messageTemplate = new ACLMessage(INFORM);
            messageTemplate.addReceiver(new AID("AgentRobot@192.168.0.176:1099/JADE",AID.ISGUID));
            messageTemplate.setContent("Main Sends Message ->");
            send(messageTemplate);

        }
    };



/*addBehaviour(new TickerBehaviour(this, 10000) {
    @Override
    protected void onTick() {
        System.out.println("Tick");
        ACLMessage messageTemplate = new ACLMessage(INFORM);
        messageTemplate.addReceiver(new AID("Agent2@192.168.0.105",AID.ISGUID));
        messageTemplate.setContent("Test true");
        send(messageTemplate);




    }


});
*/



    @Override
    protected void takeDown() {
    }

}