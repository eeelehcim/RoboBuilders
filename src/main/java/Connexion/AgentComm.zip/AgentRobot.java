package Connexion;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

import static jade.lang.acl.ACLMessage.INFORM;

public class AgentRobot extends Agent {
    @Override
    protected void setup() {
        System.out.println("local name Robot3"+getAID().getLocalName());
        System.out.println("GloBal name Robot3"+getAID().getName());
        addBehaviour(new CyclicBehaviour() {
            @Override
            public void action() {
                try {
                //    System.out.println("asd");
                    ACLMessage Message=receive();


                    if (Message!=null) {
                        System.out.println("Agent Robot Received:"+Message.getContent());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            }
        });


        addBehaviour(eachOneSec);
        addBehaviour(init_message);

    }
    @Override
    protected void takeDown() {
    }

    OneShotBehaviour init_message = new OneShotBehaviour() {
        @Override
        public void action() {
            try {

                System.out.println("One Shot Here.");
               // block(5000);
                ACLMessage messageTemplate = new ACLMessage(INFORM);
                messageTemplate.addReceiver(new AID("AgentMain@192.168.0.176:1099/JADE",AID.ISGUID));
                messageTemplate.setContent("This is one-shot - one time message - I am alive.");
                send(messageTemplate);






            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    TickerBehaviour eachOneSec = new TickerBehaviour(this, 1000) {
        @Override
        protected void onTick() {
         //   System.out.println("Tick From the Robot Agent");
            ACLMessage messageTemplate = new ACLMessage(INFORM);
            messageTemplate.addReceiver(new AID("AgentMain@192.168.0.176:1099/JADE",AID.ISGUID));
            messageTemplate.setContent("Tick From the Robot Agent");
            send(messageTemplate);

        }
    };







}
